# EduVerse AI — Personalized AI Learning Ecosystem

A working full-stack implementation of the EduVerse AI capstone: an adaptive
learning platform that builds a knowledge graph of topics, tracks per-student
mastery, recommends what to study next using a reinforcement-learning-style
policy, generates AI tutoring answers and notes, runs adaptive quizzes, and
recommends careers from a student's skill profile.

It runs entirely locally — no API keys, no external services — so you can
demo it end to end for a review or a viva, and it's built so each "AI" piece
can be swapped for the heavier production model (Llama 3, Neo4j, a real DQN)
without changing the surrounding app. See **"From prototype to production"**
below.

---

## 1. Architecture

```
Browser (HTML/CSS/JS SPA)
        │  fetch() → JSON
        ▼
Flask REST API  (backend/app.py)
        │
        ├── MODULE 1  ai_tutor.py          → TF-IDF retrieval + templated generation, mastery analytics
        ├── MODULE 2  knowledge_graph.py    → networkx graph + epsilon-greedy Q-learning
        ├── MODULE 3  assessment.py         → adaptive quizzes, performance report, cosine-similarity career match
        │
        ▼
SQLite  (backend/eduverse.db — auto-created)
```

The frontend is a single-page app (no build step) so it can run from any
static file server; the backend is a small Flask app with one file per
module, matching the three modules from the original design document.

## 2. How each module maps to the original design

| Design doc | This implementation |
|---|---|
| **Module 1** — Llama 3 for tutoring/notes, BERT for question understanding, XGBoost for performance prediction | `ai_tutor.py`: TF‑IDF + cosine similarity retrieves the most relevant topic for a free-text question (a real, standard IR technique standing in for a BERT encoder), then generates a structured answer/notes from the topic's content. Weak-topic detection reads directly from the mastery table. |
| **Module 2** — DQN/PPO agent + GNN reasoning over a Neo4j knowledge graph | `knowledge_graph.py`: topics + prerequisite edges form a directed graph (via `networkx`). A topic "unlocks" once every prerequisite's mastery clears a threshold. An **epsilon-greedy Q-learning agent** picks the best pedagogical action (`revise` / `practice` / `video` / `advance`) per topic, with the change in mastery after each quiz answer as the reward signal — a compact, fully working version of the RL loop described in the doc. |
| **Module 3** — AI exam generation, performance analysis, career recommendation | `assessment.py`: quizzes pull from a difficulty-tagged question bank and shift the easy/medium/hard mix based on current mastery. Performance is aggregated per subject. Careers are ranked by cosine similarity between the student's subject-mastery vector and predefined career skill profiles. |

Everything above is real, working code — not mocked responses — so the
mastery numbers, Q-values, and recommendations you see actually change as you
use the app.

## 3. Running it

**Requirements:** Python 3.10+, pip.

```bash
cd backend
pip install -r requirements.txt
python app.py
```

Open **http://localhost:5050** — the Flask app serves both the API and the
frontend, so there's nothing else to start. The SQLite database and all
seed content (4 subjects, 17 topics, 85 quiz questions, 5 career profiles)
are created automatically on first run.

Register a student account, then:
1. **AI Tutor** — ask a question or generate notes for a topic.
2. **Learning Path** — see the knowledge graph; click any unlocked node to
   jump straight into a quiz for it.
3. **Assessment** — take the adaptive quiz; watch mastery and the RL reward
   update after each answer.
4. **Career Signal** — see career matches update as your subject mastery
   grows.

Register a second account with role **Teacher** to see the class-overview
dashboard (aggregated mastery per student).

## 4. Project structure

```
eduverse/
├── backend/
│   ├── app.py              REST API (Flask) + session auth
│   ├── database.py         schema + seed data (subjects, topics, prereq graph, quiz bank, careers)
│   ├── ai_tutor.py         Module 1
│   ├── knowledge_graph.py  Module 2
│   ├── assessment.py       Module 3
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── style.css
    └── app.js              vanilla JS SPA, calls the REST API
```

## 5. From prototype to production

This project is intentionally built so the "AI" internals are swappable
without touching the API contracts the frontend relies on:

- **Real LLM tutoring** — replace the body of `ai_tutor.generate_answer()`
  with a call to the Llama 3 (or any) chat completion API, passing the
  matched topic's content as context (RAG). The retrieval step (TF‑IDF) can
  stay, or be upgraded to a BERT/embedding-based vector search.
- **Neo4j + GNN** — swap `networkx` for a Neo4j driver in
  `knowledge_graph.py`; the graph queries (`predecessors`, `nodes`, `edges`)
  map directly to Cypher queries. A GNN can replace the mastery-threshold
  unlock rule with a learned prerequisite-strength model.
- **DQN/PPO** — the `q_table` SQLite table already stores per-student,
  per-topic, per-action Q-values; a proper DQN (e.g. via `stable-baselines3`)
  can replace the tabular Q-learning update in `update_q_value()` while
  keeping the same state/action/reward definitions.
- **Deployment** — containerize with Docker, put SQLite behind PostgreSQL,
  and run the Flask app under Gunicorn/Uvicorn behind Nginx, matching the
  tech stack table in the original design document.

## 6. Notes for your report / viva

- The RL loop is genuinely functional: every quiz submission computes a
  reward (Δ mastery) and updates a Q-value with the standard Q-learning
  update rule `Q(s,a) ← Q(s,a) + α[r + γ·maxQ(s,·) − Q(s,a)]`.
- The knowledge graph enforces prerequisites: a topic only becomes available
  once its prerequisite's mastery crosses a threshold (0.6), which is what
  drives the "locked" nodes in the Learning Path view.
- The career recommender is explainable: you can show the exact subject
  mastery vector and the cosine similarity score behind every ranked career.
