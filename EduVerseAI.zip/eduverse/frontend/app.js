const API = "/api";
let CURRENT_USER = null;
let TOPICS_CACHE = [];

// ---------------------------------------------------------------- helpers
async function api(path, opts = {}) {
  const res = await fetch(API + path, {
    headers: { "Content-Type": "application/json" },
    credentials: "same-origin",
    ...opts,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || "Something went wrong");
  return data;
}
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function masteryColor(score) {
  if (score >= 0.75) return "var(--green)";
  if (score >= 0.4) return "var(--gold)";
  return "var(--rose)";
}
function masteryTier(score) {
  if (score >= 0.75) return "high";
  if (score >= 0.4) return "mid";
  return "low";
}

// ---------------------------------------------------------------- auth orbit decoration
function drawOrbit() {
  const g = $("#orbit-graph");
  const cx = 300, cy = 300;
  const rings = [90, 150, 210, 265];
  let svg = "";
  rings.forEach((r, i) => {
    svg += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="rgba(178,172,255,0.14)" stroke-width="1"/>`;
  });
  const nodeCount = 14;
  for (let i = 0; i < nodeCount; i++) {
    const ring = rings[i % rings.length];
    const angle = (i / nodeCount) * Math.PI * 2 + i * 0.35;
    const x = cx + ring * Math.cos(angle);
    const y = cy + ring * Math.sin(angle);
    const color = i % 3 === 0 ? "#8B6CF6" : i % 3 === 1 ? "#34D6D6" : "#3B3D63";
    svg += `<circle cx="${x}" cy="${y}" r="${3 + (i % 3)}" fill="${color}" opacity="0.85"/>`;
    if (i > 0) {
      const prevRing = rings[(i - 1) % rings.length];
      const prevAngle = ((i - 1) / nodeCount) * Math.PI * 2 + (i - 1) * 0.35;
      const px = cx + prevRing * Math.cos(prevAngle);
      const py = cy + prevRing * Math.sin(prevAngle);
      svg += `<line x1="${px}" y1="${py}" x2="${x}" y2="${y}" stroke="rgba(178,172,255,0.12)" stroke-width="1"/>`;
    }
  }
  g.innerHTML = svg;
}
drawOrbit();

// ---------------------------------------------------------------- auth flow
$$(".auth-tab").forEach(tab => {
  tab.addEventListener("click", () => {
    $$(".auth-tab").forEach(t => t.classList.remove("active"));
    tab.classList.add("active");
    const isLogin = tab.dataset.tab === "login";
    $("#login-form").classList.toggle("hidden", !isLogin);
    $("#register-form").classList.toggle("hidden", isLogin);
  });
});

$("#login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("#login-error").textContent = "";
  try {
    const user = await api("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email: $("#login-email").value, password: $("#login-password").value }),
    });
    onAuthed(user);
  } catch (err) { $("#login-error").textContent = err.message; }
});

$("#register-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  $("#register-error").textContent = "";
  try {
    const user = await api("/auth/register", {
      method: "POST",
      body: JSON.stringify({
        name: $("#reg-name").value, email: $("#reg-email").value,
        password: $("#reg-password").value, role: $("#reg-role").value,
      }),
    });
    onAuthed(user);
  } catch (err) { $("#register-error").textContent = err.message; }
});

$("#logout-btn").addEventListener("click", async () => {
  await api("/auth/logout", { method: "POST" });
  location.reload();
});

function onAuthed(user) {
  CURRENT_USER = user;
  $("#auth-screen").classList.add("hidden");
  $("#app-shell").classList.remove("hidden");
  $("#user-name").textContent = user.name;
  $("#user-role").textContent = user.role;
  $("#user-avatar").textContent = user.name.trim()[0].toUpperCase();
  $("#dash-name").textContent = user.name.split(" ")[0];
  if (user.role === "teacher") $("#nav-teacher").classList.remove("hidden");
  initApp();
}

// ---------------------------------------------------------------- navigation
$$(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => switchView(btn.dataset.view));
});
function switchView(view) {
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  $$(".view").forEach(v => v.classList.remove("active"));
  $(`#view-${view}`).classList.add("active");
  if (view === "dashboard") loadDashboard();
  if (view === "tutor") loadTutorView();
  if (view === "path") loadPathView();
  if (view === "quiz") loadQuizView();
  if (view === "careers") loadCareersView();
  if (view === "teacher") loadTeacherView();
}

// ---------------------------------------------------------------- init
async function initApp() {
  TOPICS_CACHE = await api("/topics");
  populateTopicSelects();
  loadDashboard();
}
function populateTopicSelects() {
  const grouped = {};
  TOPICS_CACHE.forEach(t => { (grouped[t.subject] ||= []).push(t); });
  const makeOptions = () => Object.entries(grouped).map(([subj, topics]) =>
    `<optgroup label="${subj}">${topics.map(t => `<option value="${t.id}">${t.name}</option>`).join("")}</optgroup>`
  ).join("");
  $("#notes-topic-select").innerHTML = makeOptions();
  $("#quiz-topic-select").innerHTML = makeOptions();
}

// ---------------------------------------------------------------- DASHBOARD (Module 1)
async function loadDashboard() {
  const [progress, weak, recommend, report] = await Promise.all([
    api("/tutor/progress"), api("/tutor/weak-topics"), api("/learning/recommend"), api("/assessment/report"),
  ]);

  const totalTopics = TOPICS_CACHE.length;
  const mastered = progress.filter(p => p.score >= 0.75).length;
  const avgAccuracy = report.subjects.length
    ? report.subjects.reduce((a, s) => a + s.accuracy, 0) / report.subjects.length : 0;
  const totalAttempts = report.subjects.reduce((a, s) => a + s.attempts, 0);

  $("#stat-grid").innerHTML = `
    <div class="stat-card"><div class="label">Topics mastered</div><div class="value">${mastered}<span style="font-size:16px;color:var(--text-faint)">/${totalTopics}</span></div><div class="sub">across all subjects</div></div>
    <div class="stat-card"><div class="label">Quiz accuracy</div><div class="value">${Math.round(avgAccuracy*100)}%</div><div class="sub">${totalAttempts} questions attempted</div></div>
    <div class="stat-card"><div class="label">Weak topics</div><div class="value">${weak.length}</div><div class="sub">flagged for review</div></div>
    <div class="stat-card"><div class="label">Subjects in progress</div><div class="value">${report.subjects.length}</div><div class="sub">of ${new Set(TOPICS_CACHE.map(t=>t.subject)).size} total</div></div>
  `;

  $("#weak-topics-list").innerHTML = weak.length
    ? weak.map(w => `
        <div class="list-item">
          <div><div class="name">${w.topic}</div><div class="meta">${w.subject}</div></div>
          <div class="mastery-badge" style="background:${masteryColor(w.mastery)}22;color:${masteryColor(w.mastery)}">${Math.round(w.mastery*100)}%</div>
        </div>`).join("")
    : `<p style="margin:0">No weak topics yet — take a quiz to generate your learning signal.</p>`;

  renderRecommend("#dash-recommend", recommend);
}

function renderRecommend(sel, rec) {
  const el = $(sel);
  if (!rec || rec.message) {
    el.innerHTML = `<p style="margin:0">${rec?.message || "Take a quiz to get a recommendation."}</p>`;
    return;
  }
  el.innerHTML = `
    <div class="recommend-action">${rec.recommended_action}</div>
    <div class="recommend-topic">${rec.topic_name} <span style="font-size:13px;color:var(--text-faint);font-family:var(--font-mono)">· ${rec.subject}</span></div>
    <p class="recommend-reason">${rec.reason}</p>
    <div class="qvalues">${Object.entries(rec.q_values).map(([k,v]) => `<span>${k}: ${v}</span>`).join("")}</div>
  `;
}

// ---------------------------------------------------------------- AI TUTOR (Module 1)
function loadTutorView() { /* topic selects already populated */ }

$("#tutor-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const input = $("#tutor-input");
  const q = input.value.trim();
  if (!q) return;
  appendChat("user", q);
  input.value = "";
  const thinking = appendChat("bot", "Thinking…");
  try {
    const res = await api("/tutor/ask", { method: "POST", body: JSON.stringify({ question: q }) });
    thinking.innerHTML = escapeHtml(res.answer).replace(/\n/g, "<br>") +
      `<span class="conf">match: ${res.matched_topic || "none"} · confidence ${res.confidence}</span>`;
  } catch (err) {
    thinking.textContent = "Sorry — something went wrong: " + err.message;
  }
});
function appendChat(role, text) {
  const log = $("#chat-log");
  const div = document.createElement("div");
  div.className = "chat-msg " + role;
  div.textContent = text;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}
function escapeHtml(s) {
  return s.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

$("#notes-generate-btn").addEventListener("click", async () => {
  const topicId = $("#notes-topic-select").value;
  if (!topicId) return;
  $("#notes-output").textContent = "Generating…";
  const res = await api(`/tutor/notes/${topicId}`);
  $("#notes-output").textContent = res.notes;
});

// ---------------------------------------------------------------- LEARNING PATH (Module 2)
async function loadPathView() {
  const [graph, recommend] = await Promise.all([api("/learning/graph"), api("/learning/recommend")]);
  renderGraph(graph);
  renderRecommend("#path-recommend", recommend);
}

function renderGraph(graph) {
  const subjectIds = Object.keys(graph.subjects).map(Number);
  const colWidth = 190, rowHeight = 62, topPad = 40, leftPad = 90;
  const nodesBySubject = {};
  subjectIds.forEach(id => nodesBySubject[id] = []);
  graph.nodes.forEach(n => nodesBySubject[n.subject_id].push(n));
  subjectIds.forEach(id => nodesBySubject[id].sort((a,b) => a.id - b.id));

  const pos = {};
  subjectIds.forEach((sid, colIdx) => {
    nodesBySubject[sid].forEach((n, rowIdx) => {
      pos[n.id] = { x: leftPad + colIdx * colWidth, y: topPad + rowIdx * rowHeight + 20 };
    });
  });

  const width = leftPad + subjectIds.length * colWidth;
  const maxRows = Math.max(...subjectIds.map(id => nodesBySubject[id].length));
  const height = topPad + maxRows * rowHeight + 60;

  let svg = `<svg viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg">`;

  subjectIds.forEach((sid, colIdx) => {
    svg += `<text class="g-subject-label" x="${leftPad + colIdx * colWidth}" y="20">${graph.subjects[sid]}</text>`;
  });

  graph.edges.forEach(e => {
    const a = pos[e.from], b = pos[e.to];
    if (!a || !b) return;
    svg += `<line class="g-edge" x1="${a.x}" y1="${a.y}" x2="${b.x}" y2="${b.y}" />`;
  });

  graph.nodes.forEach(n => {
    const p = pos[n.id];
    const color = n.unlocked ? masteryColor(n.mastery) : "#3B3D63";
    const r = 14;
    svg += `<g class="g-node ${n.unlocked ? "clickable" : ""}" data-topic="${n.id}">
      <circle cx="${p.x}" cy="${p.y}" r="${r}" fill="${color}" opacity="${n.unlocked ? 1 : 0.45}"/>
      <text x="${p.x}" y="${p.y + r + 15}" text-anchor="middle">${n.name}</text>
      <text x="${p.x}" y="${p.y + 4}" text-anchor="middle" font-family="var(--font-mono)" font-size="9.5" fill="#0B0C1F" font-weight="700">${Math.round(n.mastery*100)}</text>
    </g>`;
  });

  svg += `</svg>`;
  $("#graph-wrap").innerHTML = svg;

  $$(".g-node.clickable", $("#graph-wrap")).forEach(g => {
    g.addEventListener("click", () => {
      const topicId = g.dataset.topic;
      switchView("quiz");
      $("#quiz-topic-select").value = topicId;
      startQuiz(topicId);
    });
  });
}

// ---------------------------------------------------------------- ASSESSMENT (Module 3)
function loadQuizView() { loadPerformanceReport(); }

$("#quiz-start-btn").addEventListener("click", () => {
  const topicId = $("#quiz-topic-select").value;
  if (topicId) startQuiz(topicId);
});

async function startQuiz(topicId) {
  const area = $("#quiz-area");
  area.innerHTML = `<p>Building an adaptive quiz for you…</p>`;
  const quiz = await api(`/assessment/quiz/${topicId}?n=5`);
  if (!quiz.questions.length) {
    area.innerHTML = `<p>No questions available for this topic yet.</p>`;
    return;
  }
  area.innerHTML = `<p style="margin-bottom:14px">Starting mastery: <strong style="color:${masteryColor(quiz.mastery_before)}">${Math.round(quiz.mastery_before*100)}%</strong> — difficulty mix adapts as you answer.</p>` +
    quiz.questions.map(q => `
      <div class="quiz-card" data-qid="${q.id}">
        <div class="quiz-diff">${q.difficulty}</div>
        <div class="quiz-q">${q.question}</div>
        <div class="quiz-options">
          ${q.options.map((opt, i) => `<button class="quiz-opt" data-idx="${i}">${opt}</button>`).join("")}
        </div>
        <div class="quiz-feedback"></div>
      </div>
    `).join("");

  $$(".quiz-card", area).forEach(card => {
    const qid = card.dataset.qid;
    $$(".quiz-opt", card).forEach(optBtn => {
      optBtn.addEventListener("click", async () => {
        $$(".quiz-opt", card).forEach(b => b.disabled = true);
        const res = await api("/assessment/submit", {
          method: "POST",
          body: JSON.stringify({ topic_id: Number(topicId), question_id: Number(qid), selected_index: Number(optBtn.dataset.idx) }),
        });
        optBtn.classList.add(res.is_correct ? "correct" : "incorrect");
        card.querySelector(".quiz-feedback").textContent =
          `${res.is_correct ? "Correct" : "Not quite"} · mastery ${Math.round(res.mastery_before*100)}% → ${Math.round(res.mastery_after*100)}% (reward ${res.reward >= 0 ? "+" : ""}${res.reward})`;
      });
    });
  });
}

async function loadPerformanceReport() {
  const report = await api("/assessment/report");
  const el = $("#perf-report");
  if (!report.subjects.length) {
    el.innerHTML = `<p>Take a quiz to build your performance report.</p>`;
    return;
  }
  el.innerHTML = `
    <div class="profile-bars" style="margin-bottom:18px">
      ${report.subjects.map(s => `
        <div class="pbar-row">
          <div class="pbar-label">${s.subject}</div>
          <div class="pbar-track"><div class="pbar-fill" style="width:${Math.round(s.accuracy*100)}%"></div></div>
          <div class="pbar-val">${Math.round(s.accuracy*100)}%</div>
        </div>`).join("")}
    </div>
    <p style="font-size:12.5px">Accuracy shown per subject · ${report.subjects.reduce((a,s)=>a+s.attempts,0)} total attempts logged.</p>
  `;
}

// ---------------------------------------------------------------- CAREER SIGNAL (Module 3)
async function loadCareersView() {
  const data = await api("/assessment/careers");
  $("#career-profile").innerHTML = Object.entries(data.student_profile).map(([subj, val]) => `
    <div class="pbar-row">
      <div class="pbar-label">${subj}</div>
      <div class="pbar-track"><div class="pbar-fill" style="width:${Math.round(val*100)}%"></div></div>
      <div class="pbar-val">${Math.round(val*100)}%</div>
    </div>`).join("");

  $("#career-cards").innerHTML = data.recommendations.length
    ? data.recommendations.map((c, i) => `
        <div class="career-card">
          <div class="rank">#${i+1} match</div>
          <h3>${c.career}</h3>
          <p>${c.description}</p>
          <div class="career-match">${Math.round(c.match*100)}% alignment</div>
        </div>`).join("")
    : `<p>Take a few quizzes so the AI has a mastery profile to work from.</p>`;
}

// ---------------------------------------------------------------- TEACHER VIEW
async function loadTeacherView() {
  const tbody = $("#teacher-table tbody");
  try {
    const students = await api("/teacher/students");
    tbody.innerHTML = students.length ? students.map(s => `
      <tr>
        <td>${s.name}</td>
        <td>${s.email}</td>
        <td style="color:${masteryColor(s.overall_mastery)}">${Math.round(s.overall_mastery*100)}%</td>
        <td>${s.weak_topic_count}</td>
      </tr>`).join("") : `<tr><td colspan="4">No students yet.</td></tr>`;
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="4">${err.message}</td></tr>`;
  }
}

// ---------------------------------------------------------------- boot: resume session
(async function boot() {
  try {
    const { user } = await api("/auth/me");
    if (user) onAuthed(user);
  } catch (e) { /* not logged in */ }
})();
