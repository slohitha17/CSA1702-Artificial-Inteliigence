"""
EduVerse AI - Database layer
SQLite is used so the whole project runs with zero external services.
In a production deployment, PostgreSQL (relational data) + Neo4j (knowledge graph)
would replace this, as described in the original design doc.
"""
import sqlite3
import os
import json
import hashlib
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "eduverse.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('student','teacher')),
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

CREATE TABLE IF NOT EXISTS topics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    subject_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    definition TEXT NOT NULL,
    key_points TEXT NOT NULL,       -- JSON list
    example TEXT NOT NULL,
    common_mistakes TEXT NOT NULL,  -- JSON list
    FOREIGN KEY(subject_id) REFERENCES subjects(id)
);

CREATE TABLE IF NOT EXISTS topic_edges (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    from_topic_id INTEGER NOT NULL,   -- prerequisite
    to_topic_id INTEGER NOT NULL,     -- depends on from_topic
    FOREIGN KEY(from_topic_id) REFERENCES topics(id),
    FOREIGN KEY(to_topic_id) REFERENCES topics(id)
);

CREATE TABLE IF NOT EXISTS quiz_questions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    topic_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    options TEXT NOT NULL,      -- JSON list of 4
    correct_index INTEGER NOT NULL,
    difficulty TEXT NOT NULL CHECK(difficulty IN ('easy','medium','hard')),
    FOREIGN KEY(topic_id) REFERENCES topics(id)
);

CREATE TABLE IF NOT EXISTS mastery (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    topic_id INTEGER NOT NULL,
    score REAL NOT NULL DEFAULT 0,        -- 0..1 running mastery estimate
    attempts_count INTEGER NOT NULL DEFAULT 0,
    correct_count INTEGER NOT NULL DEFAULT 0,
    last_updated TEXT,
    UNIQUE(user_id, topic_id),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(topic_id) REFERENCES topics(id)
);

CREATE TABLE IF NOT EXISTS q_table (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    topic_id INTEGER NOT NULL,
    action TEXT NOT NULL,   -- revise | practice | video | advance
    q_value REAL NOT NULL DEFAULT 0,
    UNIQUE(user_id, topic_id, action),
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(topic_id) REFERENCES topics(id)
);

CREATE TABLE IF NOT EXISTS attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    topic_id INTEGER NOT NULL,
    question_id INTEGER NOT NULL,
    selected_index INTEGER NOT NULL,
    is_correct INTEGER NOT NULL,
    time_taken_seconds REAL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(topic_id) REFERENCES topics(id),
    FOREIGN KEY(question_id) REFERENCES quiz_questions(id)
);

CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    topic_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id),
    FOREIGN KEY(topic_id) REFERENCES topics(id)
);

CREATE TABLE IF NOT EXISTS tutor_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    matched_topic_id INTEGER,
    created_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE IF NOT EXISTS careers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT NOT NULL,
    skill_vector TEXT NOT NULL   -- JSON: {subject_name: weight}
);
"""

# ---------------------------------------------------------------------------
# Seed content: subjects -> topics (with prerequisite chain = the knowledge
# graph), a quiz bank per topic at 3 difficulty tiers, and career profiles.
# ---------------------------------------------------------------------------

SUBJECTS = ["Programming", "Data Science & AI", "Web Development", "Mathematics"]

TOPICS = {
    "Programming": [
        dict(name="Variables", description="Storing and naming data in a program.",
             definition="A variable is a named container that holds a value which can change while a program runs.",
             key_points=["Declared with a name and (often) a type", "Stored in memory and referenced by name",
                         "Naming should be descriptive", "Scope determines where a variable is visible"],
             example="age = 21  # 'age' now refers to the integer value 21",
             common_mistakes=["Using a variable before assigning it a value", "Confusing '=' (assignment) with '==' (comparison)"]),
        dict(name="Operators", description="Symbols that perform operations on values.",
             definition="Operators combine or compare values: arithmetic (+, -, *, /), relational (==, <, >), and logical (and, or, not).",
             key_points=["Arithmetic operators follow standard precedence (PEMDAS)", "Relational operators return booleans",
                         "Logical operators combine boolean expressions", "Integer vs float division differ across languages"],
             example="result = (10 + 5) * 2   # 30",
             common_mistakes=["Mixing up '=' and '=='", "Forgetting operator precedence and skipping parentheses"]),
        dict(name="Loops", description="Repeating a block of code.",
             definition="A loop repeats a block of statements while a condition holds (while) or for a known number of iterations (for).",
             key_points=["'for' loops iterate over a known range/collection", "'while' loops repeat until a condition becomes false",
                         "Infinite loops occur when the exit condition is never reached", "break/continue alter loop flow"],
             example="for i in range(5):\n    print(i)  # prints 0..4",
             common_mistakes=["Forgetting to update the loop variable, causing an infinite loop", "Off-by-one errors in the range"]),
        dict(name="Functions", description="Reusable, named blocks of logic.",
             definition="A function is a reusable block of code that takes inputs (parameters), performs a task, and can return a value.",
             key_points=["Defined once, called many times", "Parameters vs arguments", "Return values vs side effects",
                         "Local variables inside a function have their own scope"],
             example="def add(a, b):\n    return a + b",
             common_mistakes=["Forgetting the 'return' statement", "Shadowing outer variables with parameter names"]),
        dict(name="Recursion", description="A function calling itself to solve smaller subproblems.",
             definition="Recursion solves a problem by having a function call itself on a smaller version of the same problem, with a base case that stops the recursion.",
             key_points=["Every recursive function needs a base case", "Each call should move toward the base case",
                         "Uses the call stack, so deep recursion can overflow it", "Often mirrors mathematical induction"],
             example="def factorial(n):\n    if n == 0:\n        return 1\n    return n * factorial(n - 1)",
             common_mistakes=["Missing or unreachable base case causing infinite recursion", "Not trusting the recursive call to solve the subproblem"]),
    ],
    "Mathematics": [
        dict(name="Algebra Basics", description="Working with variables and equations.",
             definition="Algebra represents unknown quantities with symbols and studies the rules for manipulating equations involving them.",
             key_points=["Solve for an unknown by isolating it", "Operations must be applied to both sides equally",
                         "Linear equations graph as straight lines"],
             example="2x + 4 = 10  ->  x = 3",
             common_mistakes=["Forgetting to apply an operation to both sides", "Sign errors when moving terms across '='"]),
        dict(name="Probability", description="Measuring the likelihood of events.",
             definition="Probability quantifies how likely an event is, from 0 (impossible) to 1 (certain).",
             key_points=["P(event) = favorable outcomes / total outcomes", "Independent events multiply their probabilities",
                         "Conditional probability accounts for known information"],
             example="P(heads) for a fair coin = 1/2",
             common_mistakes=["Treating dependent events as independent", "Confusing P(A|B) with P(B|A)"]),
        dict(name="Linear Algebra", description="Vectors, matrices, and transformations.",
             definition="Linear algebra studies vectors, matrices, and the linear transformations between them — the backbone of most ML models.",
             key_points=["A matrix represents a linear transformation", "Matrix multiplication is not commutative",
                         "Dot products measure vector alignment", "Eigenvectors point in directions unchanged by a transformation"],
             example="[[1,2],[3,4]] * [1,0]^T = [1,3]^T",
             common_mistakes=["Assuming A*B = B*A for matrices", "Mismatched matrix dimensions during multiplication"]),
        dict(name="Statistics", description="Collecting, analyzing, and interpreting data.",
             definition="Statistics summarizes and draws conclusions from data using measures like mean, variance, and distributions.",
             key_points=["Mean, median, and mode summarize central tendency", "Variance/standard deviation measure spread",
                         "A normal distribution is symmetric around its mean"],
             example="Mean of [2,4,6,8] = 5",
             common_mistakes=["Using mean when the data is skewed (median is more robust)", "Confusing correlation with causation"]),
    ],
    "Data Science & AI": [
        dict(name="Python for Data Science", description="Core libraries for data work.",
             definition="Python's data-science stack (NumPy, Pandas) provides array and tabular-data structures for fast, expressive data manipulation.",
             key_points=["NumPy arrays are fixed-type and vectorized", "Pandas DataFrames model tabular data",
                         "Vectorized operations avoid slow Python loops"],
             example="df['profit'] = df['revenue'] - df['cost']",
             common_mistakes=["Looping row-by-row instead of vectorizing", "Ignoring missing values (NaN) before computing stats"]),
        dict(name="Machine Learning Basics", description="Models that learn patterns from data.",
             definition="Machine learning builds models that learn patterns from data to make predictions, rather than following hardcoded rules.",
             key_points=["Supervised learning uses labeled data", "Unsupervised learning finds structure without labels",
                         "Train/test split estimates real-world performance", "Overfitting: great on training data, poor on new data"],
             example="model.fit(X_train, y_train); model.predict(X_test)",
             common_mistakes=["Evaluating a model on its own training data", "Not scaling features before distance-based algorithms"]),
        dict(name="Neural Networks", description="Layered models inspired by the brain.",
             definition="A neural network is a stack of layers of weighted connections and non-linear activations that learns a mapping from inputs to outputs via gradient descent.",
             key_points=["A neuron computes a weighted sum plus an activation function", "Backpropagation computes gradients layer by layer",
                         "Learning rate controls the size of weight updates", "Deeper networks can model more complex functions but need more data"],
             example="output = activation(W . x + b)",
             common_mistakes=["Learning rate too high (diverges) or too low (never converges)", "No non-linearity, which collapses the network to a linear model"]),
        dict(name="NLP & LLMs", description="Teaching machines to process language.",
             definition="Natural Language Processing (NLP) enables machines to understand and generate text; modern Large Language Models (LLMs) do this using the transformer architecture and self-attention.",
             key_points=["Tokenization splits text into model-readable units", "Embeddings represent words/tokens as vectors",
                         "Self-attention lets a model weigh relevant context", "Fine-tuning adapts a pretrained model to a specific task"],
             example="'cat' and 'kitten' end up close together in embedding space",
             common_mistakes=["Assuming a language model 'understands' rather than predicts likely tokens", "Ignoring tokenizer limits when processing long text"]),
    ],
    "Web Development": [
        dict(name="HTML & CSS", description="Structure and style for the web.",
             definition="HTML defines the structure/content of a web page; CSS controls its visual presentation.",
             key_points=["HTML uses nested tags/elements", "CSS selectors target elements to style",
                         "The box model governs spacing (margin, border, padding, content)"],
             example="<p style='color:teal'>Hello</p>",
             common_mistakes=["Forgetting to close tags", "Fighting CSS specificity instead of understanding the cascade"]),
        dict(name="JavaScript Basics", description="Making pages interactive.",
             definition="JavaScript is a scripting language that runs in the browser (and beyond) to make pages interactive and dynamic.",
             key_points=["The DOM represents the page as a tree Claude/JS can manipulate", "Functions and closures are first-class",
                         "Asynchronous code uses callbacks/promises/async-await"],
             example="document.querySelector('#btn').addEventListener('click', handler)",
             common_mistakes=["Blocking the main thread with heavy synchronous work", "Not handling promise rejections"]),
        dict(name="APIs & REST", description="How frontend and backend communicate.",
             definition="A REST API exposes resources over HTTP using verbs (GET/POST/PUT/DELETE) and predictable URLs, usually exchanging JSON.",
             key_points=["Endpoints represent resources, not actions", "Status codes communicate outcome (200, 404, 500...)",
                         "Statelessness: each request carries all context needed"],
             example="GET /api/students/12  ->  200 OK { id: 12, name: 'Asha' }",
             common_mistakes=["Putting verbs in URLs (e.g. /getStudent)", "Ignoring HTTP status codes on the client"]),
        dict(name="Databases & SQL", description="Storing and querying structured data.",
             definition="A relational database stores data in tables with defined relationships; SQL is the language used to query and modify it.",
             key_points=["Primary keys uniquely identify rows", "Foreign keys model relationships between tables",
                         "JOINs combine rows from multiple tables", "Indexes speed up lookups at the cost of write speed"],
             example="SELECT name FROM students WHERE score > 80;",
             common_mistakes=["N+1 query patterns instead of a single JOIN", "No index on frequently filtered columns"]),
    ],
}

# prerequisite chains, expressed as consecutive pairs within each subject's list above
PREREQ_CHAINS = {subj: [t["name"] for t in topics] for subj, topics in TOPICS.items()}

CAREERS = [
    dict(name="AI Engineer",
         description="Builds and deploys machine learning and deep learning systems in production.",
         skill_vector={"Programming": 0.9, "Data Science & AI": 1.0, "Mathematics": 0.7, "Web Development": 0.3}),
    dict(name="Data Scientist",
         description="Analyzes data to extract insights and build predictive models.",
         skill_vector={"Programming": 0.6, "Data Science & AI": 0.9, "Mathematics": 0.9, "Web Development": 0.1}),
    dict(name="Full-Stack Web Developer",
         description="Builds complete web applications, frontend to backend.",
         skill_vector={"Programming": 0.8, "Data Science & AI": 0.1, "Mathematics": 0.3, "Web Development": 1.0}),
    dict(name="Software Engineer",
         description="Designs, builds, and maintains general-purpose software systems.",
         skill_vector={"Programming": 1.0, "Data Science & AI": 0.3, "Mathematics": 0.5, "Web Development": 0.5}),
    dict(name="Data Analyst",
         description="Turns raw data into dashboards and business insights.",
         skill_vector={"Programming": 0.4, "Data Science & AI": 0.6, "Mathematics": 0.8, "Web Development": 0.2}),
]


def _mk_question(topic_id, q, opts, correct, diff):
    return (topic_id, q, json.dumps(opts), correct, diff)


def build_quiz_bank(cur, topic_id, topic_name):
    """Generate a small but real quiz bank (3 difficulties) per topic."""
    bank = {
        "Variables": [
            ("What does the assignment 'x = 5' do?", ["Compares x to 5", "Stores 5 in x", "Deletes x", "Prints 5"], 1, "easy"),
            ("Which is a valid variable name in most languages?", ["2age", "user_age", "user age", "user-age"], 1, "easy"),
            ("What happens if you use a variable before assigning it?", ["Nothing", "It defaults to 0 always", "An error/undefined behavior", "It becomes a string"], 2, "medium"),
            ("What determines where a variable can be accessed from?", ["Its name length", "Its scope", "Its color", "The file size"], 1, "medium"),
            ("Why can shadowing an outer variable inside a function be risky?", ["It's always illegal", "It can hide the outer value unexpectedly", "It deletes the outer variable permanently", "It changes the variable's type"], 1, "hard"),
        ],
        "Operators": [
            ("What is 10 + 5 * 2 evaluated with normal precedence?", ["30", "20", "25", "15"], 1, "easy"),
            ("Which operator checks equality (not assignment)?", ["=", "==", ":=", "<>"], 1, "easy"),
            ("What does 'and' return if both sides are true?", ["False", "None", "True", "Error"], 2, "medium"),
            ("Why should you use parentheses in complex expressions?", ["They're required by law", "To make precedence explicit and avoid bugs", "They speed up execution", "They are optional decoration"], 1, "medium"),
            ("What's a common bug from confusing '=' with '=='?", ["Syntax highlighting breaks", "An assignment happens where a comparison was intended", "The program runs faster", "Nothing, they're identical"], 1, "hard"),
        ],
        "Loops": [
            ("What does a 'for' loop typically iterate over?", ["A single value", "A known range/collection", "Nothing", "Only strings"], 1, "easy"),
            ("What causes an infinite while loop?", ["The condition never becomes false", "Using 'for' instead", "Too many variables", "Fast CPUs"], 0, "easy"),
            ("What does 'break' do inside a loop?", ["Skips one iteration", "Exits the loop immediately", "Restarts the loop", "Pauses the program"], 1, "medium"),
            ("What's an off-by-one error?", ["A typo in a variable name", "Looping one time too many/few due to range bounds", "A missing semicolon", "A CPU error"], 1, "medium"),
            ("Why can nested loops be expensive?", ["They use more memory only", "Their time cost multiplies with each level", "They always crash", "They can't use break"], 1, "hard"),
        ],
        "Functions": [
            ("What is a function primarily used for?", ["Storing a single value", "Reusable, named logic", "Styling a page", "Naming a file"], 1, "easy"),
            ("What's the difference between a parameter and an argument?", ["No difference", "Parameter is the placeholder, argument is the actual value passed", "Argument is only for math functions", "Parameter is only for return values"], 1, "medium"),
            ("What happens if a function has no 'return' statement?", ["It errors", "It returns a default 'empty' value (e.g. None)", "It loops forever", "It deletes itself"], 1, "medium"),
            ("What is variable scope inside a function?", ["Global by default in most languages", "Local to that function unless declared otherwise", "Always shared with all functions", "Randomly assigned"], 1, "hard"),
            ("Why prefer small, single-purpose functions?", ["They run faster always", "They're easier to test, read, and reuse", "They use less RAM always", "Compilers require it"], 1, "hard"),
        ],
        "Recursion": [
            ("What must every recursive function have?", ["A loop", "A base case", "A global variable", "Two parameters"], 1, "easy"),
            ("What happens without a reachable base case?", ["Faster execution", "Infinite recursion / stack overflow", "A compile-time warning only", "Nothing"], 1, "medium"),
            ("Recursion uses which structure to track calls?", ["A queue", "The call stack", "A hash map", "A linked list always"], 1, "medium"),
            ("factorial(0) is typically defined as?", ["0", "1", "Undefined", "-1"], 1, "easy"),
            ("Why can deep recursion be risky in practice?", ["It's always slower than loops", "It can exceed the call stack limit", "It can't return values", "It only works on numbers"], 1, "hard"),
        ],
        "Algebra Basics": [
            ("Solve: 2x + 4 = 10", ["x=2", "x=3", "x=4", "x=6"], 1, "easy"),
            ("What must you do to both sides of an equation?", ["Apply different operations", "Apply the same operation to keep it balanced", "Nothing", "Only add"], 1, "easy"),
            ("What shape does a linear equation graph as?", ["A circle", "A straight line", "A parabola", "A random curve"], 1, "medium"),
            ("Solve: 3(x - 2) = 9", ["x=3", "x=5", "x=7", "x=1"], 1, "medium"),
            ("Why must you flip the inequality sign when multiplying by a negative?", ["It's a stylistic choice", "It preserves the true order relationship", "It's never required", "To make it look harder"], 1, "hard"),
        ],
        "Probability": [
            ("P(heads) for a fair coin?", ["1", "0", "1/2", "1/4"], 2, "easy"),
            ("What is P(event) = ?", ["Total outcomes / favorable", "Favorable outcomes / total outcomes", "Favorable * total", "1 - total"], 1, "easy"),
            ("If two events are independent, P(A and B) = ?", ["P(A) + P(B)", "P(A) * P(B)", "P(A) - P(B)", "max(P(A),P(B))"], 1, "medium"),
            ("What does P(A|B) mean?", ["P(A) and P(B) are unrelated", "Probability of A given that B occurred", "Probability of B given A", "P(A) minus P(B)"], 1, "medium"),
            ("Why is treating dependent events as independent a mistake?", ["It's not a mistake", "It overstates or understates the true joint probability", "It only affects rounding", "Probabilities can't be dependent"], 1, "hard"),
        ],
        "Linear Algebra": [
            ("A matrix represents a...", ["Single number", "Linear transformation", "Random value", "Text string"], 1, "easy"),
            ("Is matrix multiplication commutative (A*B = B*A) in general?", ["Yes always", "No, generally not", "Only for square matrices", "Only for identity matrices"], 1, "medium"),
            ("What does a dot product measure?", ["Matrix size", "Alignment/similarity between vectors", "Number of rows", "Determinant"], 1, "medium"),
            ("What is an eigenvector?", ["A random vector", "A vector whose direction is unchanged by a transformation", "The largest matrix entry", "A zero vector always"], 1, "hard"),
            ("Why must matrix dimensions match for multiplication?", ["Style convention only", "Rows of A must match columns... columns of A must match rows of B", "They never need to match", "Only for square matrices"], 1, "hard"),
        ],
        "Statistics": [
            ("Mean of [2,4,6,8]?", ["4", "5", "6", "8"], 1, "easy"),
            ("What does standard deviation measure?", ["Central value", "Spread of data around the mean", "Number of samples", "The maximum value"], 1, "easy"),
            ("Why use median over mean on skewed data?", ["Median is always bigger", "Median is less affected by outliers", "Mean is illegal in stats", "They're identical"], 1, "medium"),
            ("A normal distribution is...", ["Always skewed", "Symmetric around its mean", "Only for integers", "Undefined"], 1, "medium"),
            ("Correlation implies causation. True or false?", ["True", "False", "Only in medicine", "Only in physics"], 1, "hard"),
        ],
        "Python for Data Science": [
            ("NumPy arrays are best described as?", ["Slow, flexible lists", "Fixed-type, vectorized arrays", "Text files", "Databases"], 1, "easy"),
            ("What does a Pandas DataFrame model?", ["A single number", "Tabular (rows/columns) data", "An image", "A network graph"], 1, "easy"),
            ("Why avoid row-by-row Python loops over large DataFrames?", ["They're illegal", "Vectorized operations are much faster", "Loops don't work in Python", "No reason, it's fine"], 1, "medium"),
            ("What should you check before computing stats on a column?", ["Its color", "Missing values (NaN)", "Font size", "File name"], 1, "medium"),
            ("df['profit'] = df['revenue'] - df['cost'] demonstrates?", ["A loop", "Vectorized column-wise arithmetic", "A database join", "A syntax error"], 1, "hard"),
        ],
        "Machine Learning Basics": [
            ("Supervised learning requires?", ["No data", "Labeled data", "Only images", "A GPU always"], 1, "easy"),
            ("Why split data into train/test sets?", ["To save disk space", "To estimate performance on unseen data", "It's required by law", "To make training faster only"], 1, "easy"),
            ("What is overfitting?", ["Model performs well everywhere", "Model memorizes training data but fails to generalize", "Model trains too fast", "Model has too few parameters"], 1, "medium"),
            ("Unsupervised learning is used to?", ["Predict labels", "Find structure without labels", "Only classify images", "Replace all supervised learning"], 1, "medium"),
            ("Why evaluate a model only on held-out test data?", ["It's faster", "Testing on training data overstates real performance", "Test data is always bigger", "No real reason"], 1, "hard"),
        ],
        "Neural Networks": [
            ("A neuron computes?", ["A random number", "A weighted sum plus activation", "Only a sum", "A sorted list"], 1, "easy"),
            ("What does backpropagation compute?", ["Random weights", "Gradients layer by layer for weight updates", "The dataset size", "Nothing"], 1, "medium"),
            ("What happens if the learning rate is too high?", ["Perfect convergence", "Training may diverge/oscillate", "Nothing changes", "Training becomes instant"], 1, "medium"),
            ("Why do neural networks need non-linear activations?", ["They don't", "Otherwise the whole network collapses to a linear model", "To make code longer", "For faster training only"], 1, "hard"),
            ("Deeper networks can model...", ["Only linear functions", "More complex functions, given enough data", "Nothing new", "Only images"], 1, "hard"),
        ],
        "NLP & LLMs": [
            ("Tokenization is the process of?", ["Deleting text", "Splitting text into model-readable units", "Translating text", "Compressing images"], 1, "easy"),
            ("Embeddings represent words as?", ["Random colors", "Vectors in a continuous space", "Sound waves", "File paths"], 1, "easy"),
            ("What lets transformers weigh relevant context?", ["Recursion", "Self-attention", "Sorting", "Regular expressions"], 1, "medium"),
            ("Fine-tuning a pretrained model means?", ["Training from scratch", "Adapting it further to a specific task", "Deleting its weights", "Only changing its name"], 1, "medium"),
            ("Why is it a mistake to say an LLM 'understands' text?", ["It's not a mistake", "It predicts likely tokens statistically, not via comprehension", "LLMs are always correct", "LLMs don't process text"], 1, "hard"),
        ],
        "HTML & CSS": [
            ("HTML is primarily used for?", ["Styling", "Structure/content of a page", "Server logic", "Databases"], 1, "easy"),
            ("CSS is primarily used for?", ["Structure", "Visual presentation/styling", "Server logic", "Data storage"], 1, "easy"),
            ("The CSS box model includes?", ["Only color", "Margin, border, padding, content", "Only font size", "Only width"], 1, "medium"),
            ("What happens if you forget to close an HTML tag?", ["Nothing ever", "Layout/structure can break unexpectedly", "The page loads faster", "CSS stops working"], 1, "medium"),
            ("Why does CSS specificity matter?", ["It doesn't", "It determines which conflicting style rule wins", "It only affects load time", "It's only for colors"], 1, "hard"),
        ],
        "JavaScript Basics": [
            ("The DOM represents?", ["A database", "The page as a manipulable tree", "A CSS file", "A server"], 1, "easy"),
            ("What does addEventListener do?", ["Deletes an element", "Attaches a handler for an event like 'click'", "Styles an element", "Creates a database"], 1, "easy"),
            ("Async/await is used to handle?", ["Styling", "Asynchronous operations more readably", "HTML structure", "SQL queries only"], 1, "medium"),
            ("Why avoid blocking the main thread?", ["It doesn't matter", "It freezes the UI/page", "It speeds up rendering", "It's required for security"], 1, "medium"),
            ("What's a closure?", ["A CSS property", "A function that remembers variables from its enclosing scope", "An HTML tag", "A database index"], 1, "hard"),
        ],
        "APIs & REST": [
            ("REST endpoints should represent?", ["Actions like /getUser", "Resources like /users/12", "Only files", "Passwords"], 1, "easy"),
            ("What does a 404 status code mean?", ["Success", "Not found", "Server error", "Redirect"], 1, "easy"),
            ("What does 'stateless' mean for REST APIs?", ["Servers remember every client forever", "Each request carries all context it needs", "No data is ever stored", "APIs can't use JSON"], 1, "medium"),
            ("Which HTTP verb typically creates a new resource?", ["GET", "POST", "DELETE", "HEAD"], 1, "medium"),
            ("Why should clients check HTTP status codes?", ["They shouldn't", "To correctly detect success/failure of a request", "Status codes are decorative", "Only for GET requests"], 1, "hard"),
        ],
        "Databases & SQL": [
            ("A primary key is used to?", ["Style a table", "Uniquely identify a row", "Delete a table", "Import CSVs"], 1, "easy"),
            ("What does a JOIN do?", ["Deletes rows", "Combines rows from multiple tables", "Creates a backup", "Encrypts data"], 1, "easy"),
            ("A foreign key models?", ["A random column", "A relationship between two tables", "A CSS style", "A password"], 1, "medium"),
            ("Why add an index to a frequently filtered column?", ["It's required syntax", "It speeds up lookups on that column", "It deletes duplicate rows", "It encrypts the table"], 1, "medium"),
            ("What's the N+1 query problem?", ["A syntax error", "Running one query per row instead of a single JOIN, hurting performance", "A type of index", "A backup strategy"], 1, "hard"),
        ],
    }
    rows = [_mk_question(topic_id, *q) for q in bank.get(topic_name, [])]
    cur.executemany(
        "INSERT INTO quiz_questions (topic_id, question, options, correct_index, difficulty) VALUES (?,?,?,?,?)",
        rows,
    )


def init_db(reset=False):
    first_time = reset or not os.path.exists(DB_PATH)
    if reset and os.path.exists(DB_PATH):
        os.remove(DB_PATH)
    conn = get_db()
    cur = conn.cursor()
    cur.executescript(SCHEMA)

    cur.execute("SELECT COUNT(*) c FROM subjects")
    if cur.fetchone()["c"] > 0:
        conn.commit()
        conn.close()
        return

    # Seed subjects + topics + prerequisite edges + quiz bank
    subject_ids = {}
    for s in SUBJECTS:
        cur.execute("INSERT INTO subjects(name) VALUES (?)", (s,))
        subject_ids[s] = cur.lastrowid

    topic_ids = {}
    for subj, topics in TOPICS.items():
        for t in topics:
            cur.execute(
                """INSERT INTO topics (subject_id, name, description, definition, key_points, example, common_mistakes)
                   VALUES (?,?,?,?,?,?,?)""",
                (subject_ids[subj], t["name"], t["description"], t["definition"],
                 json.dumps(t["key_points"]), t["example"], json.dumps(t["common_mistakes"])),
            )
            topic_ids[t["name"]] = cur.lastrowid
            build_quiz_bank(cur, cur.lastrowid, t["name"])

    for subj, chain in PREREQ_CHAINS.items():
        for a, b in zip(chain, chain[1:]):
            cur.execute("INSERT INTO topic_edges (from_topic_id, to_topic_id) VALUES (?,?)",
                        (topic_ids[a], topic_ids[b]))

    for c in CAREERS:
        cur.execute("INSERT INTO careers (name, description, skill_vector) VALUES (?,?,?)",
                    (c["name"], c["description"], json.dumps(c["skill_vector"])))

    conn.commit()
    conn.close()


if __name__ == "__main__":
    init_db(reset=True)
    print("Database initialized at", DB_PATH)
