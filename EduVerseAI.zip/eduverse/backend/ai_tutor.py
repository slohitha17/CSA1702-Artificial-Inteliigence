"""
EduVerse AI - MODULE 1: Intelligent AI Tutor & Learning Analytics

Production version: this module's job would be filled by an LLM (Llama 3) for
generation and a BERT-style encoder for retrieving the most relevant topic.
Locally (no external API access in this environment) we implement the same
*pipeline* with TF-IDF + cosine similarity for retrieval (a real, standard
NLP technique) and structured template generation for notes/answers, seeded
from the topic content written into the database. Swapping in an LLM call
later only means replacing `generate_answer()` / `generate_notes()` bodies —
the interfaces and the rest of the app stay the same. See README.
"""
import json
from datetime import datetime
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from database import get_db

_vectorizer = None
_topic_matrix = None
_topic_rows = None


def _load_topic_corpus(conn):
    cur = conn.cursor()
    rows = cur.execute("SELECT id, name, description, definition, key_points FROM topics").fetchall()
    docs = []
    for r in rows:
        kp = " ".join(json.loads(r["key_points"]))
        docs.append(f"{r['name']} {r['description']} {r['definition']} {kp}")
    return rows, docs


def _get_index(conn):
    """Build (once) a TF-IDF retrieval index over all topic content."""
    global _vectorizer, _topic_matrix, _topic_rows
    if _vectorizer is None:
        _topic_rows, docs = _load_topic_corpus(conn)
        _vectorizer = TfidfVectorizer(stop_words="english")
        _topic_matrix = _vectorizer.fit_transform(docs)
    return _vectorizer, _topic_matrix, _topic_rows


def find_relevant_topic(question, conn):
    vectorizer, matrix, rows = _get_index(conn)
    q_vec = vectorizer.transform([question])
    sims = cosine_similarity(q_vec, matrix).flatten()
    best_idx = sims.argmax()
    return rows[best_idx], float(sims[best_idx])


def generate_answer(user_id, question, conn=None):
    """Retrieval-grounded answer generation (Module 1 core function)."""
    own_conn = conn is None
    conn = conn or get_db()
    topic_row, confidence = find_relevant_topic(question, conn)

    cur = conn.cursor()
    full = cur.execute("SELECT * FROM topics WHERE id=?", (topic_row["id"],)).fetchone()
    key_points = json.loads(full["key_points"])
    mistakes = json.loads(full["common_mistakes"])

    if confidence < 0.08:
        answer = ("I couldn't confidently match that to a topic in your syllabus yet. "
                   "Try rephrasing, or ask about one of: Variables, Loops, Functions, Recursion, "
                   "Machine Learning Basics, Neural Networks, HTML & CSS, SQL, Probability...")
        matched_topic_id = None
    else:
        answer = (
            f"**{full['name']}**\n\n{full['definition']}\n\n"
            f"Key points:\n- " + "\n- ".join(key_points) + "\n\n"
            f"Example:\n{full['example']}\n\n"
            f"Watch out for: {mistakes[0]}"
        )
        matched_topic_id = full["id"]

    cur.execute(
        "INSERT INTO tutor_logs (user_id, question, answer, matched_topic_id, created_at) VALUES (?,?,?,?,?)",
        (user_id, question, answer, matched_topic_id, datetime.utcnow().isoformat()),
    )
    conn.commit()
    if own_conn:
        conn.close()
    return {"answer": answer, "matched_topic": full["name"] if matched_topic_id else None, "confidence": round(confidence, 3)}


def generate_notes(topic_id, conn=None):
    """AI-generated personalized study notes for a topic (Module 1)."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    t = cur.execute("SELECT * FROM topics WHERE id=?", (topic_id,)).fetchone()
    if not t:
        if own_conn:
            conn.close()
        return None
    key_points = json.loads(t["key_points"])
    mistakes = json.loads(t["common_mistakes"])
    notes = (
        f"# {t['name']}\n\n"
        f"## Definition\n{t['definition']}\n\n"
        f"## Key Points\n" + "\n".join(f"- {k}" for k in key_points) + "\n\n"
        f"## Worked Example\n```\n{t['example']}\n```\n\n"
        f"## Common Mistakes to Avoid\n" + "\n".join(f"- {m}" for m in mistakes)
    )
    if own_conn:
        conn.close()
    return {"topic": t["name"], "notes": notes}


def identify_weak_topics(user_id, conn=None, threshold=0.5):
    """Analyzes mastery table to flag topics needing attention (Module 1)."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    rows = cur.execute(
        """SELECT t.id, t.name, s.name as subject, m.score, m.attempts_count
           FROM mastery m JOIN topics t ON t.id=m.topic_id JOIN subjects s ON s.id=t.subject_id
           WHERE m.user_id=? AND m.score < ? ORDER BY m.score ASC""",
        (user_id, threshold),
    ).fetchall()
    if own_conn:
        conn.close()
    return [{"topic_id": r["id"], "topic": r["name"], "subject": r["subject"],
              "mastery": round(r["score"], 3), "attempts": r["attempts_count"]} for r in rows]


def learning_progress_report(user_id, conn=None):
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    rows = cur.execute(
        """SELECT t.name as topic, s.name as subject, m.score, m.attempts_count, m.correct_count
           FROM mastery m JOIN topics t ON t.id=m.topic_id JOIN subjects s ON s.id=t.subject_id
           WHERE m.user_id=? ORDER BY s.name, t.name""",
        (user_id,),
    ).fetchall()
    if own_conn:
        conn.close()
    return [dict(r) for r in rows]
