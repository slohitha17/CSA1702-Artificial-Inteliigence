"""
EduVerse AI - MODULE 2: Adaptive Learning Engine
(Knowledge Graph reasoning + Reinforcement-Learning-style topic selection)

- The knowledge graph (topics + prerequisite edges) is modelled with networkx,
  mirroring how a production system would use Neo4j + a Graph Neural Network.
- Topic selection uses a real epsilon-greedy Q-learning policy over actions
  {revise, practice, video, advance} per topic, persisted in the `q_table`
  table. Reward = change in mastery after an attempt. This is a compact,
  explainable stand-in for the DQN/PPO agent described in the design doc.
"""
import json
import random
import networkx as nx
from datetime import datetime
from database import get_db

ACTIONS = ["revise", "practice", "video", "advance"]
MASTERY_UNLOCK_THRESHOLD = 0.6   # mastery needed on a topic to unlock its dependents
LEARNING_RATE = 0.3              # Q-learning alpha
DISCOUNT = 0.9                   # Q-learning gamma
EPSILON = 0.15                   # exploration rate


def build_graph(conn=None):
    """Builds the full knowledge graph (all subjects) as a networkx DiGraph."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    g = nx.DiGraph()
    for row in cur.execute("SELECT id, name, subject_id FROM topics"):
        g.add_node(row["id"], name=row["name"], subject_id=row["subject_id"])
    for row in cur.execute("SELECT from_topic_id, to_topic_id FROM topic_edges"):
        g.add_edge(row["from_topic_id"], row["to_topic_id"])
    if own_conn:
        conn.close()
    return g


def get_mastery_map(user_id, conn):
    cur = conn.cursor()
    rows = cur.execute("SELECT topic_id, score FROM mastery WHERE user_id=?", (user_id,)).fetchall()
    return {r["topic_id"]: r["score"] for r in rows}


def unlocked_topics(user_id, conn, g=None):
    """A topic is unlocked once all its prerequisites have mastery >= threshold."""
    g = g or build_graph(conn)
    mastery = get_mastery_map(user_id, conn)
    unlocked = []
    for node in g.nodes:
        preds = list(g.predecessors(node))
        if all(mastery.get(p, 0.0) >= MASTERY_UNLOCK_THRESHOLD for p in preds):
            unlocked.append(node)
    return unlocked, mastery


def _get_q(cur, user_id, topic_id, action):
    row = cur.execute(
        "SELECT q_value FROM q_table WHERE user_id=? AND topic_id=? AND action=?",
        (user_id, topic_id, action),
    ).fetchone()
    return row["q_value"] if row else 0.0


def _set_q(cur, user_id, topic_id, action, value):
    cur.execute(
        """INSERT INTO q_table (user_id, topic_id, action, q_value) VALUES (?,?,?,?)
           ON CONFLICT(user_id, topic_id, action) DO UPDATE SET q_value=excluded.q_value""",
        (user_id, topic_id, action, value),
    )


def choose_action(user_id, topic_id, conn):
    """Epsilon-greedy policy over the 4 pedagogical actions for one topic."""
    cur = conn.cursor()
    q_values = {a: _get_q(cur, user_id, topic_id, a) for a in ACTIONS}
    if random.random() < EPSILON:
        return random.choice(ACTIONS), q_values
    best_action = max(q_values, key=q_values.get)
    return best_action, q_values


def update_q_value(user_id, topic_id, action, reward, conn):
    """Q-learning update: Q(s,a) <- Q(s,a) + alpha * (reward + gamma*max(Q(s,.)) - Q(s,a))"""
    cur = conn.cursor()
    current_q = _get_q(cur, user_id, topic_id, action)
    next_best = max(_get_q(cur, user_id, topic_id, a) for a in ACTIONS)
    new_q = current_q + LEARNING_RATE * (reward + DISCOUNT * next_best - current_q)
    _set_q(cur, user_id, topic_id, action, new_q)
    conn.commit()
    return new_q


def update_mastery(user_id, topic_id, is_correct, conn):
    """Exponential-moving-average mastery update; returns (old_score, new_score, reward)."""
    cur = conn.cursor()
    row = cur.execute("SELECT score, attempts_count, correct_count FROM mastery WHERE user_id=? AND topic_id=?",
                       (user_id, topic_id)).fetchone()
    old_score = row["score"] if row else 0.0
    attempts = (row["attempts_count"] if row else 0) + 1
    correct = (row["correct_count"] if row else 0) + (1 if is_correct else 0)

    alpha = 0.35  # how fast mastery reacts to the latest attempt
    signal = 1.0 if is_correct else 0.0
    new_score = old_score + alpha * (signal - old_score)
    new_score = max(0.0, min(1.0, new_score))

    cur.execute(
        """INSERT INTO mastery (user_id, topic_id, score, attempts_count, correct_count, last_updated)
           VALUES (?,?,?,?,?,?)
           ON CONFLICT(user_id, topic_id) DO UPDATE SET
             score=excluded.score, attempts_count=excluded.attempts_count,
             correct_count=excluded.correct_count, last_updated=excluded.last_updated""",
        (user_id, topic_id, new_score, attempts, correct, datetime.utcnow().isoformat()),
    )
    conn.commit()
    reward = new_score - old_score  # the RL reward signal
    return old_score, new_score, reward


def recommend_next(user_id, conn=None):
    """
    Core of Module 2: walk the knowledge graph, find unlocked-but-not-yet-mastered
    topics, and use the learned Q-values to decide the best pedagogical action
    for the weakest one.
    """
    own_conn = conn is None
    conn = conn or get_db()
    g = build_graph(conn)
    unlocked, mastery = unlocked_topics(user_id, conn, g)

    candidates = [t for t in unlocked if mastery.get(t, 0.0) < 0.95]
    if not candidates:
        if own_conn:
            conn.close()
        return None

    # Prioritize the weakest unlocked topic (classic "zone of proximal development" heuristic)
    candidates.sort(key=lambda t: mastery.get(t, 0.0))
    target_topic = candidates[0]

    action, q_values = choose_action(user_id, target_topic, conn)

    cur = conn.cursor()
    topic_row = cur.execute("SELECT t.id, t.name, s.name as subject FROM topics t JOIN subjects s ON s.id=t.subject_id WHERE t.id=?",
                             (target_topic,)).fetchone()

    result = {
        "topic_id": topic_row["id"],
        "topic_name": topic_row["name"],
        "subject": topic_row["subject"],
        "current_mastery": round(mastery.get(target_topic, 0.0), 3),
        "recommended_action": action,
        "q_values": {k: round(v, 3) for k, v in q_values.items()},
        "reason": _explain(action, mastery.get(target_topic, 0.0)),
    }
    if own_conn:
        conn.close()
    return result


def _explain(action, score):
    if action == "revise":
        return f"Mastery is {score:.0%}, revisiting core concepts first will help before more practice."
    if action == "practice":
        return f"Mastery is {score:.0%} — targeted practice questions should push this over the mastery threshold."
    if action == "video":
        return "A visual walkthrough may help make this concept click before trying more questions."
    return "Mastery is strong here — ready to advance to the next topic."


def full_graph_view(user_id, conn=None):
    """Returns nodes+edges with mastery scores, for rendering the graph in the UI."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    g = build_graph(conn)
    mastery = get_mastery_map(user_id, conn)
    unlocked, _ = unlocked_topics(user_id, conn, g)
    unlocked_set = set(unlocked)

    nodes = []
    for n, data in g.nodes(data=True):
        nodes.append({
            "id": n,
            "name": data["name"],
            "subject_id": data["subject_id"],
            "mastery": round(mastery.get(n, 0.0), 3),
            "unlocked": n in unlocked_set,
        })
    edges = [{"from": u, "to": v} for u, v in g.edges]

    subjects = {r["id"]: r["name"] for r in cur.execute("SELECT id, name FROM subjects")}
    if own_conn:
        conn.close()
    return {"nodes": nodes, "edges": edges, "subjects": subjects}
