"""
EduVerse AI - MODULE 3: AI Assessment & Career Recommendation System
"""
import json
import numpy as np
from datetime import datetime
from database import get_db
import knowledge_graph as kg


def generate_quiz(user_id, topic_id, n=5, conn=None):
    """Adaptive quiz: difficulty mix shifts based on the student's current mastery."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    mastery_row = cur.execute("SELECT score FROM mastery WHERE user_id=? AND topic_id=?",
                               (user_id, topic_id)).fetchone()
    mastery = mastery_row["score"] if mastery_row else 0.0

    if mastery < 0.35:
        weights = {"easy": 0.6, "medium": 0.3, "hard": 0.1}
    elif mastery < 0.7:
        weights = {"easy": 0.3, "medium": 0.5, "hard": 0.2}
    else:
        weights = {"easy": 0.1, "medium": 0.4, "hard": 0.5}

    questions = []
    for diff, w in weights.items():
        want = max(1, round(n * w)) if diff != "hard" else round(n * w)
        rows = cur.execute(
            "SELECT id, question, options, difficulty FROM quiz_questions WHERE topic_id=? AND difficulty=? ORDER BY RANDOM() LIMIT ?",
            (topic_id, diff, want),
        ).fetchall()
        for r in rows:
            questions.append({
                "id": r["id"], "question": r["question"],
                "options": json.loads(r["options"]), "difficulty": r["difficulty"],
            })
    questions = questions[:n] if len(questions) > n else questions
    if own_conn:
        conn.close()
    return {"topic_id": topic_id, "mastery_before": round(mastery, 3), "questions": questions}


def submit_answer(user_id, topic_id, question_id, selected_index, time_taken_seconds=None, conn=None):
    """Grades one answer, updates mastery (Module 2 state) and the Q-table (RL reward)."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    q = cur.execute("SELECT correct_index FROM quiz_questions WHERE id=?", (question_id,)).fetchone()
    is_correct = int(selected_index) == q["correct_index"]

    cur.execute(
        """INSERT INTO attempts (user_id, topic_id, question_id, selected_index, is_correct, time_taken_seconds, created_at)
           VALUES (?,?,?,?,?,?,?)""",
        (user_id, topic_id, question_id, selected_index, int(is_correct), time_taken_seconds, datetime.utcnow().isoformat()),
    )
    conn.commit()

    old_score, new_score, reward = kg.update_mastery(user_id, topic_id, is_correct, conn)

    # Feed the reward back into whichever action the RL agent last recommended for this topic.
    action, _ = kg.choose_action(user_id, topic_id, conn)
    kg.update_q_value(user_id, topic_id, action, reward, conn)

    if own_conn:
        conn.close()
    return {"is_correct": is_correct, "mastery_before": round(old_score, 3),
            "mastery_after": round(new_score, 3), "reward": round(reward, 3)}


def performance_report(user_id, conn=None):
    """Subject-wise strengths/weaknesses, accuracy, and improvement trend."""
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()
    rows = cur.execute(
        """SELECT s.name as subject, AVG(m.score) as avg_mastery, SUM(m.attempts_count) as attempts,
                  SUM(m.correct_count) as correct
           FROM mastery m JOIN topics t ON t.id=m.topic_id JOIN subjects s ON s.id=t.subject_id
           WHERE m.user_id=? GROUP BY s.name""",
        (user_id,),
    ).fetchall()

    subject_stats = []
    for r in rows:
        accuracy = (r["correct"] / r["attempts"]) if r["attempts"] else 0
        subject_stats.append({
            "subject": r["subject"],
            "avg_mastery": round(r["avg_mastery"] or 0, 3),
            "attempts": r["attempts"] or 0,
            "accuracy": round(accuracy, 3),
        })

    trend_rows = cur.execute(
        """SELECT date(created_at) as day, AVG(is_correct)*1.0 as day_accuracy
           FROM attempts WHERE user_id=? GROUP BY day ORDER BY day""",
        (user_id,),
    ).fetchall()
    trend = [{"day": r["day"], "accuracy": round(r["day_accuracy"], 3)} for r in trend_rows]

    if own_conn:
        conn.close()
    return {"subjects": subject_stats, "trend": trend}


def recommend_careers(user_id, top_k=3, conn=None):
    """
    Builds a skill vector for the student from subject-level mastery, then ranks
    predefined career profiles by cosine similarity — a lightweight, explainable
    stand-in for the learned recommendation model in the design doc.
    """
    own_conn = conn is None
    conn = conn or get_db()
    cur = conn.cursor()

    subjects = [r["name"] for r in cur.execute("SELECT name FROM subjects ORDER BY name")]
    perf = performance_report(user_id, conn)["subjects"]
    perf_map = {p["subject"]: p["avg_mastery"] for p in perf}
    student_vec = np.array([perf_map.get(s, 0.0) for s in subjects])

    careers = cur.execute("SELECT name, description, skill_vector FROM careers").fetchall()
    scored = []
    if np.linalg.norm(student_vec) > 0:
        for c in careers:
            sv = json.loads(c["skill_vector"])
            career_vec = np.array([sv.get(s, 0.0) for s in subjects])
            denom = (np.linalg.norm(student_vec) * np.linalg.norm(career_vec))
            sim = float(np.dot(student_vec, career_vec) / denom) if denom else 0.0
            scored.append({"career": c["name"], "description": c["description"], "match": round(sim, 3)})
        scored.sort(key=lambda x: x["match"], reverse=True)
    if own_conn:
        conn.close()
    return {"student_profile": dict(zip(subjects, [round(v, 3) for v in student_vec.tolist()])),
            "recommendations": scored[:top_k]}
