"""
EduVerse AI - Flask backend
Serves the REST API (under /api/*) and the static frontend.
Run: python app.py   (see README for details)
"""
import os
import json
from datetime import datetime
from functools import wraps
from flask import Flask, request, jsonify, session, send_from_directory

from database import get_db, init_db, hash_password
import ai_tutor
import knowledge_graph as kg
import assessment

FRONTEND_DIR = os.path.join(os.path.dirname(__file__), "..", "frontend")

app = Flask(__name__, static_folder=FRONTEND_DIR, static_url_path="")
app.secret_key = os.environ.get("EDUVERSE_SECRET", "dev-secret-change-me")


def login_required(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"error": "Not authenticated"}), 401
        return f(*args, **kwargs)
    return wrapper


def current_user_row(conn):
    return conn.execute("SELECT * FROM users WHERE id=?", (session["user_id"],)).fetchone()


# ---------------------------------------------------------------- Frontend
@app.route("/")
def index():
    return send_from_directory(FRONTEND_DIR, "index.html")


# ---------------------------------------------------------------- Auth
@app.post("/api/auth/register")
def register():
    data = request.get_json(force=True)
    name, email, password = data.get("name"), data.get("email", "").lower().strip(), data.get("password")
    role = data.get("role", "student")
    if not name or not email or not password:
        return jsonify({"error": "name, email and password are required"}), 400
    if role not in ("student", "teacher"):
        role = "student"

    conn = get_db()
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO users (name, email, password_hash, role, created_at) VALUES (?,?,?,?,?)",
            (name, email, hash_password(password), role, datetime.utcnow().isoformat()),
        )
        conn.commit()
        user_id = cur.lastrowid
        session["user_id"] = user_id
        session["role"] = role
        return jsonify({"id": user_id, "name": name, "email": email, "role": role})
    except Exception:
        return jsonify({"error": "An account with that email already exists"}), 409
    finally:
        conn.close()


@app.post("/api/auth/login")
def login():
    data = request.get_json(force=True)
    email, password = data.get("email", "").lower().strip(), data.get("password")
    conn = get_db()
    row = conn.execute("SELECT * FROM users WHERE email=?", (email,)).fetchone()
    conn.close()
    if not row or row["password_hash"] != hash_password(password or ""):
        return jsonify({"error": "Invalid email or password"}), 401
    session["user_id"] = row["id"]
    session["role"] = row["role"]
    return jsonify({"id": row["id"], "name": row["name"], "email": row["email"], "role": row["role"]})


@app.post("/api/auth/logout")
def logout():
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/auth/me")
def me():
    if "user_id" not in session:
        return jsonify({"user": None})
    conn = get_db()
    row = current_user_row(conn)
    conn.close()
    if not row:
        session.clear()
        return jsonify({"user": None})
    return jsonify({"user": {"id": row["id"], "name": row["name"], "email": row["email"], "role": row["role"]}})


# ---------------------------------------------------------------- Catalog
@app.get("/api/subjects")
def subjects():
    conn = get_db()
    rows = conn.execute("SELECT id, name FROM subjects ORDER BY name").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/topics")
def topics():
    conn = get_db()
    rows = conn.execute(
        "SELECT t.id, t.name, t.description, s.name as subject FROM topics t JOIN subjects s ON s.id=t.subject_id ORDER BY s.name, t.id"
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


# ---------------------------------------------------------------- MODULE 1: AI Tutor
@app.post("/api/tutor/ask")
@login_required
def tutor_ask():
    data = request.get_json(force=True)
    question = (data.get("question") or "").strip()
    if not question:
        return jsonify({"error": "question is required"}), 400
    conn = get_db()
    result = ai_tutor.generate_answer(session["user_id"], question, conn)
    conn.close()
    return jsonify(result)


@app.get("/api/tutor/notes/<int:topic_id>")
@login_required
def tutor_notes(topic_id):
    conn = get_db()
    result = ai_tutor.generate_notes(topic_id, conn)
    conn.close()
    if not result:
        return jsonify({"error": "topic not found"}), 404
    return jsonify(result)


@app.get("/api/tutor/weak-topics")
@login_required
def tutor_weak_topics():
    conn = get_db()
    result = ai_tutor.identify_weak_topics(session["user_id"], conn)
    conn.close()
    return jsonify(result)


@app.get("/api/tutor/progress")
@login_required
def tutor_progress():
    conn = get_db()
    result = ai_tutor.learning_progress_report(session["user_id"], conn)
    conn.close()
    return jsonify(result)


# ---------------------------------------------------------------- MODULE 2: Adaptive Engine
@app.get("/api/learning/graph")
@login_required
def learning_graph():
    conn = get_db()
    result = kg.full_graph_view(session["user_id"], conn)
    conn.close()
    return jsonify(result)


@app.get("/api/learning/recommend")
@login_required
def learning_recommend():
    conn = get_db()
    result = kg.recommend_next(session["user_id"], conn)
    conn.close()
    if not result:
        return jsonify({"message": "All unlocked topics are mastered — great work!"})
    return jsonify(result)


# ---------------------------------------------------------------- MODULE 3: Assessment & Careers
@app.get("/api/assessment/quiz/<int:topic_id>")
@login_required
def assessment_quiz(topic_id):
    n = int(request.args.get("n", 5))
    conn = get_db()
    result = assessment.generate_quiz(session["user_id"], topic_id, n=n, conn=conn)
    conn.close()
    return jsonify(result)


@app.post("/api/assessment/submit")
@login_required
def assessment_submit():
    data = request.get_json(force=True)
    conn = get_db()
    result = assessment.submit_answer(
        session["user_id"], data["topic_id"], data["question_id"], data["selected_index"],
        data.get("time_taken_seconds"), conn,
    )
    conn.close()
    return jsonify(result)


@app.get("/api/assessment/report")
@login_required
def assessment_report():
    conn = get_db()
    result = assessment.performance_report(session["user_id"], conn)
    conn.close()
    return jsonify(result)


@app.get("/api/assessment/careers")
@login_required
def assessment_careers():
    conn = get_db()
    result = assessment.recommend_careers(session["user_id"], conn=conn)
    conn.close()
    return jsonify(result)


# ---------------------------------------------------------------- Teacher dashboard
@app.get("/api/teacher/students")
@login_required
def teacher_students():
    conn = get_db()
    if session.get("role") != "teacher":
        conn.close()
        return jsonify({"error": "Teacher access only"}), 403
    students = conn.execute("SELECT id, name, email FROM users WHERE role='student' ORDER BY name").fetchall()
    out = []
    for s in students:
        report = assessment.performance_report(s["id"], conn)
        overall = (sum(r["avg_mastery"] for r in report["subjects"]) / len(report["subjects"])) if report["subjects"] else 0
        weak = ai_tutor.identify_weak_topics(s["id"], conn)
        out.append({"id": s["id"], "name": s["name"], "email": s["email"],
                     "overall_mastery": round(overall, 3), "weak_topic_count": len(weak)})
    conn.close()
    return jsonify(out)


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5050, debug=True)
